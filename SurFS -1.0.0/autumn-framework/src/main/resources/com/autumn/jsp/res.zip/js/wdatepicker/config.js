var langList = 
[
	{name:'zh-cn',	charset:'GBK'}
];

var skinList = 
[
	{name:'default',	charset:'gb2312'}
];