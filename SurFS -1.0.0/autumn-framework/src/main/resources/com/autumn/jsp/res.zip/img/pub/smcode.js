function Ajax_do(){//通道服务操作确认(启动/关闭)
		var myajax=new Ajax.Request('svncodes.do',{
            method:'get',
			parameters:'ajax=true',
   			onComplete:update_do
   		});
}

function update_do(req)
{
	var json=req.responseText.evalJSON(true); 
	var ids = json.ids;
	var contents = json.contents;
	var i=0;
	var count=ids.length;
    for (i=0;i<count;i++){
		var id=ids[i];
		var content=contents[i];
		//alert(id+":"+content);
		document.getElementById(id).innerHTML=content;
    }
	//setInterval(Ajax_do(),5*1000*100);
}

function confirmmodified(msg){
    for (var i=0;i<document.Form1.elements.length;i++)
    {
      var e = document.Form1.elements[i];
      if(e.name=="modified"){
		 if(e.checked){
			 return confirm(msg);
		 }
	  }
    }
	return false;
}

function confirmupdated(msg){
    for (var i=0;i<document.Form1.elements.length;i++)
    {
      var e = document.Form1.elements[i];
      if(e.name=="updated"){
		 if(e.checked){
			 return confirm(msg);
		 }
	  }
    }
	return false;
}

function selectmodified(bol){
    for (var i=0;i<document.Form1.elements.length;i++)
    {
      var e = document.Form1.elements[i];
      if(e.name=="modified"){
         e.checked = bol;
	   }
    }
}

function selectupdated(bol){
    for (var i=0;i<document.Form1.elements.length;i++)
    {
      var e = document.Form1.elements[i];
      if(e.name=="updated"){
         e.checked = bol;
	   }
    }
}

function setcheck(idvalue){
	var e=document.getElementById(idvalue);
	if(e!=null){
		e.checked = !e.checked;
	}
}