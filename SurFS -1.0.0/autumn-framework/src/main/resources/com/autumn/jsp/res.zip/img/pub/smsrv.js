function Ajax_doSrv(srvid){//通道服务操作确认(启动/关闭)
	var dotype=document.getElementById("dolinkmsg"+srvid).innerHTML;
  var msg="";
  var newmsg="";
	if (dotype=='关闭服务'){
		msg="确认关闭服务（"+srvid+"）?";
		newmsg="正在关闭...";
		dotype="close";
	}
	else if (dotype=='启动服务'){
		msg="确认启动服务（"+srvid+"）?";
		newmsg="正在启动...";
		dotype="start";
	}
	else return false;
    if(confirm(msg)){
    	document.getElementById("dolinkmsg"+srvid).innerHTML=newmsg;
		var myajax=new Ajax.Request('services.do',{
            method:'get',
			parameters:'dotype='+dotype+'&id='+srvid,
   			onComplete:update_do
   		});
    }else{
	   return false;
	}
}


function update_do(req)
{
	var json=req.responseText.evalJSON(true); 
	var srvId = json.id;
	document.getElementById("dolinkmsg"+srvId).innerHTML=json.title;
	document.getElementById("domsg").innerHTML=json.doMsg;
	document.getElementById("imgname"+srvId).src=json.imgname;
}


//通道服务操作确认
function deleteconfirm(srvid){
    var msg="确认删除服务（"+srvid+"）?";
    if(confirm(msg)){
		document.getElementById("Form1").dotype.value="delete";
		document.getElementById("Form1").id.value=srvid;
		document.getElementById("Form1").submit();
		return true;
    }else{
	   return false;
	}
}