function onSelectImg(value){
	var arry = document.getElementById("imgtable");
	var trobj=document.getElementById(value);
	var trArry = arry.getElementsByTagName("tr");
	for( var i = 0 ; i < trArry.length ; i++ ){
		if(trArry[i] != trobj){
			trArry[i].style.backgroundImage='';
		}else{
			trArry[i].style.backgroundImage='url(../img/pub/over.gif)';
		}
	}
}

function deletedbpool(id){//连接池
    var msg="确认删除连接池（"+id+"）?";
    if(confirm(msg)){
		document.getElementById("Form1").dotype.value="delete";
		document.getElementById("Form1").jndiname.value=id;
		document.getElementById("Form1").submit();
		return true;
    }else{
	   return false;
	}
}


function deletelog(id){//日志目录
    var msg="确认删除日志目录（"+id+"）?";
    if(confirm(msg)){
		document.getElementById("Form1").dotype.value="delete";
		document.getElementById("Form1").logname.value=id;
		document.getElementById("Form1").submit();
		return true;
    }else{
	   return false;
	}
}

function deleteattribute(path,key){//日志目录
    var msg="确认删除变量（"+path;
	if(path=='/'){
		msg=msg+key;
	}else{
		msg=msg+'/'+key;
	}
	msg=msg+"）?";
    if(confirm(msg)){
		document.getElementById("Form1").dotype.value="delete";
		document.getElementById("Form1").path.value=path;
		document.getElementById("Form1").key.value=key;
		document.getElementById("Form1").submit();
		return true;
    }else{
	   return false;
	}
}

function deletemap(id,datasource){//日志目录
    var msg="确认删除映射（"+id+"）?";
    if(confirm(msg)){
		document.getElementById("Form1").dotype.value="delete";
		document.getElementById("Form1").id.value=id;
		document.getElementById("Form1").datasource.value=datasource;
		document.getElementById("Form1").submit();
		return true;
    }else{
	   return false;
	}
}

function deletesoap(id){//日志目录
    var msg="确认删除SOAP服务（"+id+"）?";
    if(confirm(msg)){
		document.getElementById("Form1").dotype.value="delete";
		document.getElementById("Form1").id.value=id;
		document.getElementById("Form1").submit();
		return true;
    }else{
	   return false;
	}
}

function deleteweb(id){//日志目录
    var msg="确认删除WEB目录（"+id+"）?";
    if(confirm(msg)){
		document.getElementById("Form1").dotype.value="delete";
		document.getElementById("Form1").id.value=id;
		document.getElementById("Form1").submit();
		return true;
    }else{
	   return false;
	}
}

function deleteuser(id){//日志目录
    var msg="确认删除用户（"+id+"）?";
    if(confirm(msg)){
		document.getElementById("Form1").dotype.value="delete";
		document.getElementById("Form1").id.value=id;
		document.getElementById("Form1").submit();
		return true;
    }else{
	   return false;
	}
}

function deletecode(id){//日志目录
    var msg="确认删除工程（"+id+"）?";
    if(confirm(msg)){
		document.getElementById("Form1").dotype.value="delete";
		document.getElementById("Form1").id.value=id;
		document.getElementById("Form1").submit();
		return true;
    }else{
	   return false;
	}
}

function deleteaction(id,dirname){
    var msg="确认删除目录（"+dirname+"）的控制器"+id+"?";
    if(confirm(msg)){
		document.getElementById("Form1").dotype.value="delete";
		document.getElementById("Form1").id.value=id;
		document.getElementById("Form1").dirName.value=dirname;
		document.getElementById("Form1").submit();
		return true;
    }else{
	   return false;
	}
}


//弹出窗口
function openwindow( url, winName, theWidth, theHeight, scrolls ) {
	xposition=0; yposition=0;
	if ((parseInt(navigator.appVersion) >= 4 )){
		xposition = 0;
		yposition = 0;
	}
	var theproperty= "width=" + theWidth + "," ;
	theproperty+= "height=" + theHeight + "," ;
	theproperty+= "location=0," ;
	theproperty+= "menubar=0,";
	theproperty+= "resizable=0,";
	if(scrolls)
		theproperty+= "scrollbars=" + scrolls + ",";
	else
		theproperty+= "scrollbars=0,";
	theproperty+= "status=0," ;
	theproperty+= "titlebar=0,";
	theproperty+= "toolbar=0,";
	theproperty+= "hotkeys=0,";
	theproperty+= "screenx=" + xposition + ","; //仅适用于Netscape
	theproperty+= "screeny=" + yposition + ","; //仅适用于Netscape
	theproperty+= "left=" + xposition + ","; //IE
	theproperty+= "top=" + yposition; //IE
	return( window.open(url,winName,theproperty ) );
}
/**
 * 强制弹出窗口
 */
function popWindow(url) {
//window.showModelessDialog(url,"CHINAZindexP","center:no;dialogLeft:5px;dialogTop:5px;scroll:true;status:0;help:0;dialogWidth:600px;dialogHeight:600px");
openwindow(url,'',600,400,0);
}


function checkloadclass(){
	if(!document.Form1.isread.checked){
		alert("确认你已经了解重载类的注意事项！");
		return false;
	}
	return true;
}

function checkloadmap(){
	if(!document.Form1.isread2.checked){
		alert("确认你已经了解重载页面控制器的注意事项！");
		return false;
	}
	return true;
}

//修改账号验证
function checkLoginuser(){
	if(document.Form1.username.value.replace(" ","").length ==0){
		alert("请输入用户名！");
		document.Form1.username.focus();
		return false;
	}
	if(document.Form1.password.value.replace(" ","").length==0){
		alert("请输入密码！");
		document.Form1.password.focus();
		return false;
	}
	if((document.Form1.newpwd1.value != document.Form1.newpwd2.value)){
		alert("确认密码不一致！");
		document.Form1.newpwd2.focus();
		return false;
	}
	return true;
}